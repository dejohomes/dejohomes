import type { StructureResolver } from "sanity/structure";

export const structure: StructureResolver = (S) => S.list().title("Dejohomes content").items([
  S.listItem().title("Property listings").schemaType("listing").child(S.documentTypeList("listing").title("Property listings").defaultOrdering([{ field: "_createdAt", direction: "desc" }])),
  S.listItem().title("Enquiries").schemaType("enquiry").child(S.documentTypeList("enquiry").title("Enquiries").defaultOrdering([{ field: "createdAt", direction: "desc" }])),
  S.divider(),
  S.listItem().title("Blog posts").schemaType("post").child(S.documentTypeList("post").title("Blog posts").defaultOrdering([{ field: "publishedAt", direction: "desc" }])),
  S.listItem().title("Testimonials").schemaType("testimonial").child(S.documentTypeList("testimonial").title("Testimonials")),
  S.listItem().title("FAQs").schemaType("faq").child(S.documentTypeList("faq").title("FAQs").defaultOrdering([{ field: "order", direction: "asc" }])),
  S.listItem().title("Team members").schemaType("teamMember").child(S.documentTypeList("teamMember").title("Team members")),
  S.listItem().title("Project gallery").schemaType("galleryItem").child(S.documentTypeList("galleryItem").title("Project gallery").defaultOrdering([{ field: "date", direction: "desc" }])),
  S.divider(),
  S.listItem().title("Site settings").id("siteSettings").child(S.document().schemaType("siteSettings").documentId("siteSettings"))
]);
