import { defineField, defineType } from "sanity";
export default defineType({
  name: "listing", title: "Property listings", type: "document",
  fields: [
    defineField({ name: "title", title: "Listing name", type: "string", validation: r => r.required() }),
    defineField({ name: "slug", title: "Page link", type: "slug", options: { source: "title", maxLength: 80 }, validation: r => r.required() }),
    defineField({ name: "estate", title: "Estate or community", type: "string", validation: r => r.required() }),
    defineField({ name: "district", title: "Area in Abuja", type: "string", options: { list: ["Asokoro II", "Kitti-Kabusa", "Kuje", "Lugbe", "Kubwa", "Gwagwalada", "Idu", "Karsana", "Guzape", "Other"] }, validation: r => r.required() }),
    defineField({ name: "price", title: "Price in naira", type: "number", validation: r => r.required().min(1) }),
    defineField({ name: "previousPrice", title: "Previous price (optional)", type: "number", description: "Show a crossed-out price when there is a confirmed promotion.", validation: r => r.min(1) }),
    defineField({ name: "size", title: "Property size (in square metres)", type: "number", validation: r => r.required().min(1) }),
    defineField({ name: "propertyType", title: "Home or property type", type: "string", description: "For example, 4 Bedroom Terrace Duplex or 3 Bedroom Bungalow." }),
    defineField({ name: "titleType", title: "Title or document type", type: "string", options: { list: ["Certificate of Occupancy", "Governor's Consent", "Right of Occupancy", "Deed of Assignment", "Survey Plan"] } }),
    defineField({ name: "paymentPlan", title: "Payment plan details", type: "text", rows: 3 }),
    defineField({ name: "description", title: "About this property", type: "text", rows: 6, validation: r => r.required() }),
    defineField({ name: "status", title: "Availability", type: "string", initialValue: "available", options: { list: [{ title: "Available", value: "available" }, { title: "Few available", value: "few" }, { title: "Sold", value: "sold" }] }, validation: r => r.required() }),
    defineField({ name: "featured", title: "Show on the homepage", type: "boolean", initialValue: false }),
    defineField({ name: "address", title: "Map address or directions", type: "string" }),
    defineField({ name: "latitude", title: "Map latitude (optional)", type: "number" }),
    defineField({ name: "longitude", title: "Map longitude (optional)", type: "number" }),
    defineField({ name: "amenities", title: "Estate amenities", type: "array", of: [{ type: "string" }], options: { layout: "tags" } }),
    defineField({ name: "images", title: "Photos (drag to reorder)", type: "array", of: [{ type: "image", options: { hotspot: true } }], validation: r => r.min(1) }),
    defineField({ name: "videoUrl", title: "Video or virtual tour link (optional)", type: "url" }),
    defineField({ name: "seoTitle", title: "Google result title", type: "string" }),
    defineField({ name: "seoDescription", title: "Google result description", type: "text", rows: 2 })
  ], preview: { select: { title: "title", subtitle: "estate", media: "images.0" } }
});
