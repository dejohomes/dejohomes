import { defineField, defineType } from "sanity";
export default defineType({ name: "siteSettings", title: "Site settings", type: "document", __experimental_actions: ["update", "publish"], fields: [
  defineField({ name: "companyName", title: "Company name", type: "string", initialValue: "Dejohomes" }),
  defineField({ name: "heroTitle", title: "Homepage headline", type: "string" }),
  defineField({ name: "heroText", title: "Homepage introduction", type: "text", rows: 3 }),
  defineField({ name: "aboutText", title: "About the company", type: "text", rows: 5 }),
  defineField({ name: "phone", title: "Phone number", type: "string" }),
  defineField({ name: "whatsapp", title: "WhatsApp number (international format)", type: "string" }),
  defineField({ name: "email", title: "Contact email", type: "string" }),
  defineField({ name: "address", title: "Office address", type: "text", rows: 2 }),
  defineField({ name: "registration", title: "Company registration details", type: "string" }),
  defineField({ name: "instagram", title: "Instagram link", type: "url" }),
  defineField({ name: "facebook", title: "Facebook link", type: "url" }),
  defineField({ name: "seoTitle", title: "Default Google result title", type: "string" }),
  defineField({ name: "seoDescription", title: "Default Google result description", type: "text", rows: 2 })
] });
