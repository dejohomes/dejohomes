import { defineField, defineType } from "sanity";
export default defineType({ name: "post", title: "Blog posts", type: "document", fields: [
  defineField({ name: "title", title: "Article title", type: "string", validation: r => r.required() }),
  defineField({ name: "slug", title: "Page link", type: "slug", options: { source: "title" }, validation: r => r.required() }),
  defineField({ name: "excerpt", title: "Short summary", type: "text", rows: 3 }),
  defineField({ name: "coverImage", title: "Cover photo", type: "image", options: { hotspot: true } }),
  defineField({ name: "publishedAt", title: "Publish date", type: "datetime" }),
  defineField({ name: "body", title: "Article content", type: "array", of: [{ type: "block" }] })
] });
