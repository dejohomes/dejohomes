import { defineField, defineType } from "sanity";
export default defineType({ name: "galleryItem", title: "Project gallery", type: "document", fields: [
  defineField({ name: "title", title: "Project or event", type: "string", validation: r => r.required() }),
  defineField({ name: "image", title: "Photo", type: "image", options: { hotspot: true }, validation: r => r.required() }),
  defineField({ name: "caption", title: "Caption", type: "string" }),
  defineField({ name: "date", title: "Date", type: "date" })
] });
