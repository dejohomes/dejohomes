import listing from "./listing";
import post from "./post";
import testimonial from "./testimonial";
import faq from "./faq";
import teamMember from "./teamMember";
import galleryItem from "./galleryItem";
import siteSettings from "./siteSettings";
import enquiry from "./enquiry";
export const schemaTypes = [listing, post, testimonial, faq, teamMember, galleryItem, siteSettings, enquiry];
