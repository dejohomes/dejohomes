import { defineField, defineType } from "sanity";
export default defineType({ name: "enquiry", title: "Enquiries", type: "document", fields: [
  defineField({ name: "name", title: "Customer name", type: "string" }),
  defineField({ name: "email", title: "Email address", type: "string" }),
  defineField({ name: "phone", title: "Phone or WhatsApp", type: "string" }),
  defineField({ name: "message", title: "Message", type: "text", rows: 4 }),
  defineField({ name: "listingTitle", title: "Property of interest", type: "string" }),
  defineField({ name: "kind", title: "Enquiry type", type: "string" }),
  defineField({ name: "createdAt", title: "Received", type: "datetime" }),
  defineField({ name: "handled", title: "Handled", type: "boolean", initialValue: false })
] });
