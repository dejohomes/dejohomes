import { defineField, defineType } from "sanity";
export default defineType({ name: "testimonial", title: "Testimonials", type: "document", fields: [
  defineField({ name: "name", title: "Customer name", type: "string", validation: r => r.required() }),
  defineField({ name: "quote", title: "What they said", type: "text", rows: 4, validation: r => r.required() }),
  defineField({ name: "location", title: "Customer location", type: "string" }),
  defineField({ name: "photo", title: "Photo (optional)", type: "image" }),
  defineField({ name: "featured", title: "Feature on the homepage", type: "boolean", initialValue: true })
] });
