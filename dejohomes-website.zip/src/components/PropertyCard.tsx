import Link from "next/link";
import { naira } from "@/lib/properties";
import type { Property } from "@/lib/properties";
import { Icon } from "./Icon";
export function PropertyCard({ property }: { property: Property }) { return <article className="property-card">
  <Link className="property-image" href={`/properties/${property.slug}`} aria-label={`View ${property.estate}`}><img src={property.image} alt={`${property.estate} ${property.size} sqm ${property.propertyType || "property"} render`} loading="lazy" decoding="async"/><span className={`status-pill ${property.status}`}>{property.status === "few" ? "Few available" : property.status === "sold" ? "Sold" : "Available"}</span>{property.imagePlaceholder&&<span className="sample-note">Render pending</span>}<span className="image-arrow"><Icon name="arrow" size={17}/></span></Link>
  <div className="property-content"><div className="property-location"><Icon name="pin" size={15}/>{property.estate} <span>·</span> {property.address || property.district}</div><Link href={`/properties/${property.slug}`} className="property-title">{property.title}</Link><div className="property-specs"><span>{property.size} sqm</span><span>{property.propertyType || property.titleType}</span></div><div className="property-price"><strong>{naira(property.price)}</strong>{property.previousPrice&&<del>{naira(property.previousPrice)}</del>}<span>advertised price</span></div></div>
</article>; }
