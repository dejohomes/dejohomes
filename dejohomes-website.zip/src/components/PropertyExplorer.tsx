"use client";
import { useMemo, useState } from "react";
import type { Property } from "@/lib/properties";
import { naira } from "@/lib/properties";
import { PropertyCard } from "./PropertyCard";

export function PropertyExplorer({ properties }: { properties: Property[] }) {
  const [district, setDistrict] = useState("All areas");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [minSize, setMinSize] = useState("");
  const [propertyType, setPropertyType] = useState("Any type");
  const [status, setStatus] = useState("all");
  const [sort, setSort] = useState("newest");
  const prices = [...new Set(properties.map(property => property.price))].sort((a,b) => a-b);
  const sizes = [...new Set(properties.map(property => property.size))].sort((a,b) => a-b);
  const types = [...new Set(properties.map(property => property.propertyType).filter((type): type is string => Boolean(type)))];

  const results = useMemo(() => {
    const filtered = properties.filter(property =>
      (district === "All areas" || property.district === district) &&
      (!minPrice || property.price >= Number(minPrice)) &&
      (!maxPrice || property.price <= Number(maxPrice)) &&
      (!minSize || property.size >= Number(minSize)) &&
      (propertyType === "Any type" || property.propertyType === propertyType) &&
      (status === "all" || property.status === status)
    );
    return filtered.sort((a,b) => sort === "price-low" ? a.price-b.price : sort === "price-high" ? b.price-a.price : 0);
  }, [properties,district,minPrice,maxPrice,minSize,propertyType,status,sort]);

  return <>
    <div className="filter-bar">
      <label>Area<select value={district} onChange={event=>setDistrict(event.target.value)}><option>All areas</option>{[...new Set(properties.map(property=>property.district))].map(area=><option key={area}>{area}</option>)}</select></label>
      <label>Minimum price<select value={minPrice} onChange={event=>setMinPrice(event.target.value)}><option value="">No minimum</option>{prices.map(price=><option value={price} key={price}>From {naira(price)}</option>)}</select></label>
      <label>Maximum price<select value={maxPrice} onChange={event=>setMaxPrice(event.target.value)}><option value="">No maximum</option>{prices.map(price=><option value={price} key={price}>Up to {naira(price)}</option>)}</select></label>
      <label>Size<select value={minSize} onChange={event=>setMinSize(event.target.value)}><option value="">Any size</option>{sizes.map(size=><option value={size} key={size}>{size} sqm and above</option>)}</select></label>
      <label>Home type<select value={propertyType} onChange={event=>setPropertyType(event.target.value)}><option>Any type</option>{types.map(type=><option key={type}>{type}</option>)}</select></label>
      <label>Availability<select value={status} onChange={event=>setStatus(event.target.value)}><option value="all">All statuses</option><option value="available">Available</option><option value="few">Few available</option><option value="sold">Sold</option></select></label>
      <label>Sort by<select value={sort} onChange={event=>setSort(event.target.value)}><option value="newest">Recommended</option><option value="price-low">Price: low to high</option><option value="price-high">Price: high to low</option></select></label>
    </div>
    <p className="results-line">{results.length} {results.length===1?"property":"properties"} to explore</p>
    {results.length ? <div className="property-grid">{results.map(property=><PropertyCard key={property.slug} property={property}/>)}</div> : <div className="empty-state"><h3>Nothing in this search just yet.</h3><p>Try changing a filter or get in touch and we’ll help you find a fit.</p></div>}
  </>;
}
