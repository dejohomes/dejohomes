import Link from "next/link";
import { Icon } from "./Icon";
import { defaultSettings } from "@/lib/siteSettings";
import type { SiteSettings } from "@/lib/siteSettings";
export function Footer({ settings = defaultSettings }: { settings?: SiteSettings }) { return <footer className="site-footer"><div className="wrap footer-top">
  <div className="footer-brand"><Link className="brand brand-light" href="/" aria-label="Dejohomes home"><img className="brand-logo" src="/dejohomes-logo.webp" alt="Dejohomes - Real Estate | Investment | Architecture"/></Link><p>Thoughtful homes. Clear conversations.<br/>A future you can feel good about.</p><a className="footer-social" href={`https://wa.me/${settings.whatsapp}`}><Icon name="whatsapp" size={18}/> Chat with our team</a></div>
  <div className="footer-column"><h3>Explore</h3><Link href="/properties">Available properties</Link><Link href="/about">Our story</Link><Link href="/how-it-works">How it works</Link><Link href="/gallery">Project gallery</Link><Link href="/journal">The journal</Link></div>
  <div className="footer-column"><h3>Get in touch</h3><a href={`tel:${settings.phone.replace(/\s/g, "")}`}>{settings.phone}</a><a href={`mailto:${settings.email}`}>{settings.email}</a><span>{settings.address}</span><Link href="/contact">Book a site visit <Icon name="arrow" size={15}/></Link></div>
</div><div className="wrap footer-bottom"><span>© {new Date().getFullYear()} Dejohomes. All rights reserved.</span><div><Link href="/privacy">Privacy</Link><Link href="/terms">Terms</Link><span>Made for a life well rooted.</span></div></div></footer> }
 