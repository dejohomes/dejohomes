"use client";
import Link from "next/link";
import { useState } from "react";
import { Icon } from "./Icon";
import { defaultSettings } from "@/lib/siteSettings";
import type { SiteSettings } from "@/lib/siteSettings";
const links = [["Properties", "/properties"], ["Our story", "/about"], ["How it works", "/how-it-works"], ["Journal", "/journal"], ["Contact", "/contact"]];
export function Header({ settings = defaultSettings }: { settings?: SiteSettings }) {
  const [open, setOpen] = useState(false);
  return <header className="site-header"><div className="header-inner wrap">
    <Link className="brand" href="/" aria-label="Dejohomes home"><img className="brand-logo" src="/dejohomes-logo.webp" alt="Dejohomes - Real Estate | Investment | Architecture"/></Link>
    <nav className={open ? "main-nav open" : "main-nav"} aria-label="Main navigation">{links.map(([label, href]) => <Link key={href} href={href} onClick={() => setOpen(false)}>{label}</Link>)}<Link className="nav-mobile-cta" href="/properties">Explore properties <Icon name="arrow" size={16}/></Link></nav>
    <a className="button button-dark header-cta" href={`https://wa.me/${settings.whatsapp}`}>Let’s talk <Icon name="arrow" size={16}/></a>
    <button className="menu-toggle" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen(!open)}><Icon name={open ? "close" : "menu"}/></button>
  </div></header>;
}
