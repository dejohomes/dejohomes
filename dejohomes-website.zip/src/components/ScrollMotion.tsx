"use client";
import { useEffect } from "react";

export function ScrollMotion() {
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || !("IntersectionObserver" in window)) return;

    const revealObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -36px 0px" });

    const observeContent = () => {
      const items = document.querySelectorAll("main section:not(.hero), .property-card, .process-card, .contact-card, .trust-point");
      items.forEach((item, index) => {
        if (item.classList.contains("motion-target")) return;
        item.classList.add("motion-target");
        (item as HTMLElement).style.setProperty("--motion-delay", `${(index % 4) * 70}ms`);
        revealObserver.observe(item);
      });
      document.body.classList.add("motion-ready");
    };

    observeContent();
    const pageObserver = new MutationObserver(observeContent);
    const main = document.querySelector("main");
    if (main) pageObserver.observe(main, { childList: true, subtree: true });

    return () => {
      revealObserver.disconnect();
      pageObserver.disconnect();
      document.body.classList.remove("motion-ready");
    };
  }, []);

  return null;
}
