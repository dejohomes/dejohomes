type Props = { name: "arrow" | "pin" | "check" | "whatsapp" | "phone" | "menu" | "close" | "arrowUp" | "shield" | "document" | "compass"; size?: number };
export function Icon({ name, size = 20 }: Props) {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.7, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, "aria-hidden": true as const };
  const paths: Record<Props["name"], React.ReactNode> = {
    arrow: <><path d="M4 12h15"/><path d="m13 5 7 7-7 7"/></>, pin: <><path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></>,
    check: <path d="m5 12 4 4L19 6"/>, whatsapp: <><path d="M20 11.5a8 8 0 0 1-11.8 7L4 20l1.5-4A8 8 0 1 1 20 11.5Z"/><path d="M9 9c.6 2 2 3.5 4 4l1-1 2 1c-.2 1.2-1.1 2-2.4 2-3.3-.2-6.4-3.4-6.4-6.2C7.2 7.5 8 7 9 7z"/></>,
    phone: <path d="M5 4h3l2 5-2 1.5a14 14 0 0 0 5.5 5.5L15 14l5 2v3a2 2 0 0 1-2 2C10 20.5 3.5 14 3 6a2 2 0 0 1 2-2Z"/>,
    menu: <><path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h16"/></>, close: <><path d="m6 6 12 12"/><path d="M18 6 6 18"/></>,
    arrowUp: <><path d="M12 19V5"/><path d="m5 12 7-7 7 7"/></>, shield: <><path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/></>,
    document: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/><path d="M8 13h8M8 17h8"/></>,
    compass: <><circle cx="12" cy="12" r="10"/><path d="m16 8-2.5 5.5L8 16l2.5-5.5L16 8Z"/></>
  };
  return <svg {...common}>{paths[name]}</svg>;
}
