import { Icon } from "./Icon";
import { defaultSettings } from "@/lib/siteSettings";
import type { SiteSettings } from "@/lib/siteSettings";
export function WhatsApp({ settings = defaultSettings }: { settings?: SiteSettings }) { return <a className="whatsapp-float" href={`https://wa.me/${settings.whatsapp}?text=Hello%20Dejohomes%2C%20I%27d%20love%20to%20learn%20more%20about%20your%20properties.`} aria-label="Chat with Dejohomes on WhatsApp" target="_blank" rel="noreferrer"><Icon name="whatsapp" size={23}/><span>Let’s chat</span></a>; }
