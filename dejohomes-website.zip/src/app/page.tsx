import Link from "next/link";
import { PropertyCard } from "@/components/PropertyCard";
import { Icon } from "@/components/Icon";
import { getProperties, getSiteSettings } from "@/lib/sanity";
import { naira } from "@/lib/properties";

export default async function Home() {
  const [inventory, settings] = await Promise.all([getProperties(), getSiteSettings()]);
  const featured = inventory.filter(property => property.status !== "sold" && (property.featured || !property.imagePlaceholder));
  const estates = Array.from(new Set(inventory.map(property => property.estate))).map(name => {
    const listings = inventory.filter(property => property.estate === name);
    const first = listings[0];
    return {
      name,
      district: first.district,
      address: first.address || first.district,
      image: first.image,
      count: listings.length,
      startingPrice: Math.min(...listings.map(property => property.price)),
      href: `/properties/${first.slug}`,
    };
  });
  const startingPrice = inventory.length ? Math.min(...inventory.map(property => property.price)) : 0;

  return <>
    <section className="home-hero">
      <div className="home-hero-image" aria-hidden="true" />
      <div className="wrap home-hero-content">
        <div className="home-hero-copy">
          <span className="home-eyebrow"><span /> Real estate · Investment · Architecture</span>
          <h1>Find a place<br/>to <em>feel at home.</em></h1>
          <p>{settings.heroText}</p>
          <div className="home-hero-actions">
            <Link className="button home-gold-button" href="/properties">Explore properties <Icon name="arrow" size={17}/></Link>
            <a className="home-quiet-link" href={`https://wa.me/${settings.whatsapp}`} target="_blank" rel="noreferrer">Talk with our team <Icon name="arrow" size={15}/></a>
          </div>
        </div>
        <div className="home-hero-caption"><span>01 / ABUJA, NIGERIA</span><span>Places to live. Room to grow.</span></div>
      </div>
      <div className="home-hero-stats">
        <div><span>Curated opportunities</span><strong>{inventory.length.toString().padStart(2, "0")}</strong></div>
        <div><span>Abuja locations</span><strong>{estates.length.toString().padStart(2, "0")}</strong></div>
        <div><span>Property options from</span><strong>{startingPrice ? naira(startingPrice) : "Ask our team"}</strong></div>
        <Link href="/properties" aria-label="Browse all Dejohomes properties"><Icon name="arrow" size={19}/></Link>
      </div>
    </section>

    <section className="home-intro wrap">
      <div className="home-intro-mark">D<span>.</span></div>
      <p>Buying property is a big decision.<br/><strong>We make the next step feel clear.</strong></p>
      <span>Thoughtful guidance, honest details<br/>and a team that knows Abuja.</span>
    </section>

    <section className="section home-listings">
      <div className="wrap">
        <div className="home-section-head">
          <div><p className="section-kicker">A good place to start</p><h2>Find your kind of home.</h2><p>Explore every current option with its home type, size, location and advertised price.</p></div>
          <Link href="/properties" className="home-outline-link">View all properties <Icon name="arrow" size={16}/></Link>
        </div>
        <div className="property-grid">{featured.map(property => <PropertyCard key={property.slug} property={property}/>)}</div>
      </div>
    </section>

    <section className="home-estates-section">
      <div className="wrap">
        <div className="home-section-head home-light-head">
          <div><p className="section-kicker">Explore our developments</p><h2>Three places to picture your future.</h2><p>Start with a location, then explore the home types and sizes available there.</p></div>
          <span className="home-index">ABUJA · FCT</span>
        </div>
        <div className="home-estate-grid">{estates.map((estate, index) => <Link key={estate.name} href={estate.href} className="home-estate-card">
          <div className="home-estate-photo" style={{backgroundImage:`url('${estate.image}')`}}><span>0{index + 1}</span><div><Icon name="pin" size={14}/>{estate.address}</div></div>
          <div className="home-estate-info"><div><h3>{estate.name}</h3><p>{estate.count} home {estate.count === 1 ? "option" : "options"} · from {naira(estate.startingPrice)}</p></div><span className="home-estate-arrow"><Icon name="arrow" size={17}/></span></div>
        </Link>)}</div>
      </div>
    </section>

    <section className="home-approach section">
      <div className="wrap home-approach-grid">
        <div className="home-approach-image"><span>DEJOHOMES / ABUJA</span></div>
        <div className="home-approach-copy"><p className="section-kicker">A more considered way to buy</p><h2>Good decisions start with clear details.</h2><p>We believe finding a home should feel exciting and grounded. Our team helps you understand the property, ask the right questions and see the location before you decide.</p>
          <div className="home-promises"><div><span>01</span><p><strong>Know what you’re considering</strong>Clear property sizes, home types and advertised prices.</p></div><div><span>02</span><p><strong>See the location</strong>Arrange a guided visit and experience the area for yourself.</p></div><div><span>03</span><p><strong>Talk to a real person</strong>Get answers from a team ready to help you take the next step.</p></div></div>
          <Link className="home-text-link" href="/how-it-works">How the process works <Icon name="arrow" size={16}/></Link>
        </div>
      </div>
    </section>

    <section className="home-final-cta"><div className="wrap home-final-inner"><div><p className="section-kicker">Your next chapter starts somewhere</p><h2>Let’s find the right place.</h2><p>Tell us what home looks like for you. We’ll help you explore the possibilities.</p></div><Link className="button home-gold-button" href="/contact">Start a conversation <Icon name="arrow" size={17}/></Link></div></section>
  </>;
}
