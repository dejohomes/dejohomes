import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { PortableText } from "@portabletext/react";
import { getPost, getPosts } from "@/lib/sanity";
export async function generateStaticParams(){const posts=await getPosts();return posts.map(post=>({slug:post.slug}));}
export async function generateMetadata({params}:{params:Promise<{slug:string}>}):Promise<Metadata>{const {slug}=await params;const post=await getPost(slug);return post?{title:post.title,description:post.excerpt,openGraph:{images:post.image?[post.image]:[]}}:{title:"Article not found"};}
export default async function Article({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const post=await getPost(slug);if(!post)notFound();return <><section className="page-hero"><div className="wrap"><div className="breadcrumb"><Link href="/">Home</Link> / <Link href="/journal">Journal</Link> / {post.title}</div><p className="section-kicker">{post.publishedAt?new Date(post.publishedAt).toLocaleDateString("en-NG",{dateStyle:"long"}):"Dejohomes journal"}</p><h1>{post.title}</h1><p>{post.excerpt}</p></div></section>{post.image&&<div className="wrap"><div className="gallery-main" style={{backgroundImage:`url('${post.image}')`}}/></div>}<article className="content-section"><div className="wrap legal-copy article-copy"><PortableText value={post.body as never}/><Link href="/journal" className="text-link" style={{color:"var(--green)",marginTop:30}}>← Back to the journal</Link></div></article></>}
