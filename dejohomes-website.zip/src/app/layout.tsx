import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { WhatsApp } from "@/components/WhatsApp";
import { CookieNotice } from "@/components/CookieNotice";
import { ScrollMotion } from "@/components/ScrollMotion";
import { getSiteSettings } from "@/lib/sanity";

export async function generateMetadata(): Promise<Metadata> { const settings=await getSiteSettings(); return {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://dejohomes.com"),
  title: { default: settings.seoTitle || "Dejohomes | Find your place in Abuja", template: "%s | Dejohomes" },
  description: settings.seoDescription,
  openGraph: { type: "website", siteName: settings.companyName, title: settings.seoTitle, description: settings.seoDescription, images: [{ url: "/dejohomes-logo.webp", width: 1800, height: 505, alt: "Dejohomes brand logo" }] },
  robots: { index: true, follow: true }
}; }

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { const settings=await getSiteSettings(); return <html lang="en"><body><ScrollMotion/><Header settings={settings}/><main>{children}</main><Footer settings={settings}/><WhatsApp settings={settings}/><CookieNotice/></body></html>; }
