import { getProperties } from "@/lib/sanity";
import { PropertyExplorer } from "@/components/PropertyExplorer";
export default async function PropertiesPage() { const inventory=await getProperties(); return <><section className="page-hero"><div className="wrap"><p className="section-kicker">Our properties · Abuja</p><h1>Find a home that feels right.</h1><p>Compare current locations, property types, sizes and prices. Our team can help with the details.</p></div></section><section className="content-section"><div className="wrap"><PropertyExplorer properties={inventory}/></div></section></>; }
