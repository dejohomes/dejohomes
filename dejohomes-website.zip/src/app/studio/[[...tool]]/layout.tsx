import "./studio.css";
export const metadata = { title: "Dejohomes Studio" };
export default function StudioLayout({ children }: { children: React.ReactNode }) { return children; }
