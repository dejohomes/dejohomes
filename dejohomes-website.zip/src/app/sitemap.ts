import type { MetadataRoute } from "next";
import { getProperties } from "@/lib/sanity";
export default async function sitemap(): Promise<MetadataRoute.Sitemap> { const base=process.env.NEXT_PUBLIC_SITE_URL||"https://dejohomes.com"; const listings=await getProperties(); return ["","/properties","/about","/how-it-works","/gallery","/journal","/contact","/privacy","/terms"].map(path=>({url:`${base}${path}`,lastModified:new Date()})).concat(listings.map(p=>({url:`${base}/properties/${p.slug}`,lastModified:new Date()}))); }
