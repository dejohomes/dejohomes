import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@sanity/client";
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

export const runtime = "nodejs";
const recent = new Map<string, number[]>();
function validText(value: unknown, limit: number) { return typeof value === "string" && value.trim().length > 0 && value.length <= limit; }
export async function POST(request: NextRequest) {
  const origin = request.headers.get("origin");
  const host = request.headers.get("x-forwarded-host") || request.headers.get("host");
  if (origin && host && new URL(origin).host !== host) return NextResponse.json({ error: "Invalid request origin." }, { status: 403 });
  if (process.env.NODE_ENV === "production" && (!process.env.SANITY_API_WRITE_TOKEN || !process.env.RESEND_API_KEY || !process.env.ENQUIRY_TO_EMAIL || !process.env.ENQUIRY_FROM_EMAIL || !process.env.UPSTASH_REDIS_REST_URL || !process.env.UPSTASH_REDIS_REST_TOKEN)) return NextResponse.json({ error: "Enquiry service is not fully configured." }, { status: 503 });
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  if (process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN) {
    const redis = new Redis({ url: process.env.UPSTASH_REDIS_REST_URL, token: process.env.UPSTASH_REDIS_REST_TOKEN });
    const limiter = new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(5, "1 m"), prefix: "dejohomes:enquiry" });
    const { success } = await limiter.limit(ip); if (!success) return NextResponse.json({ error: "Please wait a moment before trying again." }, { status: 429 });
  } else {
    const now = Date.now(); const attempts = (recent.get(ip) || []).filter(time => now - time < 60_000);
    if (attempts.length >= 5) return NextResponse.json({ error: "Please wait a moment before trying again." }, { status: 429 });
    attempts.push(now); recent.set(ip, attempts);
  }
  try {
    const body = await request.json();
    if (typeof body.website === "string" && body.website.trim()) return NextResponse.json({ ok: true });
    if (!validText(body.name, 100) || !validText(body.phone, 40) || !validText(body.message, 2000) || (body.email && (typeof body.email !== "string" || body.email.length > 200 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)))) return NextResponse.json({ error: "Please check the required fields." }, { status: 400 });
    const safe = (value: unknown) => typeof value === "string" ? value.trim() : "";
    const record = { _type: "enquiry", name: safe(body.name), phone: safe(body.phone), email: safe(body.email), message: safe(body.message), listingTitle: safe(body.listingTitle).slice(0, 160), kind: safe(body.kind).slice(0, 80), createdAt: new Date().toISOString(), handled: false };
    if (process.env.NEXT_PUBLIC_SANITY_PROJECT_ID && process.env.SANITY_API_WRITE_TOKEN) {
      const client = createClient({ projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID, dataset: process.env.NEXT_PUBLIC_SANITY_DATASET || "production", apiVersion: "2025-01-01", token: process.env.SANITY_API_WRITE_TOKEN, useCdn: false });
      await client.create(record);
    } else if (process.env.NODE_ENV === "production") {
      console.error("Enquiry storage is not configured"); return NextResponse.json({ error: "Enquiry service is unavailable." }, { status: 503 });
    } else console.info("Development enquiry received", { ...record, email: record.email ? "provided" : "not provided" });
    if (process.env.RESEND_API_KEY && process.env.ENQUIRY_TO_EMAIL && process.env.ENQUIRY_FROM_EMAIL) {
      const response = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify({ from: process.env.ENQUIRY_FROM_EMAIL, to: [process.env.ENQUIRY_TO_EMAIL], subject: `${record.kind || "New enquiry"}${record.listingTitle ? ` · ${record.listingTitle}` : ""}`, text: `Name: ${record.name}\nPhone: ${record.phone}\nEmail: ${record.email || "Not provided"}\nProperty: ${record.listingTitle || "General enquiry"}\n\n${record.message}` }) });
      if (!response.ok) console.error("Enquiry email delivery failed", response.status);
    }
    return NextResponse.json({ ok: true });
  } catch (error) { console.error("Enquiry submission failed", error); return NextResponse.json({ error: "Unable to submit enquiry." }, { status: 500 }); }
}
