import { NextRequest, NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
export async function POST(request: NextRequest) {
  const secret = request.nextUrl.searchParams.get("secret");
  if (!process.env.SANITY_REVALIDATE_SECRET || secret !== process.env.SANITY_REVALIDATE_SECRET) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try { const body = await request.json(); const type = body?._type; if (type === "listing") { revalidatePath("/"); revalidatePath("/properties"); revalidatePath("/properties/[slug]", "page"); } else if (type === "siteSettings") { revalidatePath("/", "layout"); revalidatePath("/about"); revalidatePath("/contact"); } else if (type === "post") { revalidatePath("/journal"); revalidatePath("/journal/[slug]", "page"); } return NextResponse.json({ revalidated: true, type: type || "unknown" }); }
  catch { return NextResponse.json({ error: "Invalid webhook payload" }, { status: 400 }); }
}
