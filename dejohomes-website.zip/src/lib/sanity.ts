import { createClient } from "next-sanity";
import { properties as demoProperties } from "./properties";
import type { Property } from "./properties";
import { SiteSettings, defaultSettings } from "./siteSettings";

const projectId = process.env.NEXT_PUBLIC_SANITY_PROJECT_ID;
export const hasSanityConfig = Boolean(projectId && projectId !== "your-sanity-project-id" && projectId !== "replace-me");
export const sanity = hasSanityConfig ? createClient({ projectId: projectId!, dataset: process.env.NEXT_PUBLIC_SANITY_DATASET || "production", apiVersion: "2025-01-01", useCdn: !process.env.SANITY_API_READ_TOKEN, token: process.env.SANITY_API_READ_TOKEN }) : null;

type SanityListing = { title: string; slug?: { current?: string }; estate: string; district: string; address?: string; price: number; previousPrice?: number; size: number; propertyType?: string; titleType: string; status: string; featured?: boolean; description: string; imageUrl?: string; imageUrls?: string[]; amenities?: string[]; paymentPlan?: string; seoTitle?: string; seoDescription?: string };
function optimizedImage(url: string | undefined, width = 1400) { if (!url || !url.includes("cdn.sanity.io")) return url; return `${url}?auto=format&fit=max&w=${width}&q=82`; }
export async function getSiteSettings(): Promise<SiteSettings> {
  if (!sanity) return defaultSettings;
  try { const row = await sanity.fetch<Partial<SiteSettings> | null>(`*[_type == "siteSettings"][0]{companyName, heroTitle, heroText, aboutText, phone, whatsapp, email, address, registration, instagram, facebook, seoTitle, seoDescription}`, {}, { next: { revalidate: 60, tags: ["site-settings"] } }); return { ...defaultSettings, ...row }; }
  catch (error) { console.error("Sanity site settings could not be loaded", error); return defaultSettings; }
}
export type Testimonial = { name: string; quote: string; location?: string };
export async function getTestimonials(): Promise<Testimonial[]> {
  if (!sanity) return [];
  try { return await sanity.fetch<Testimonial[]>(`*[_type == "testimonial" && featured == true] | order(_createdAt desc) {name,quote,location}`, {}, { next: { revalidate: 60, tags: ["testimonials"] } }); }
  catch (error) { console.error("Sanity testimonials could not be loaded", error); return []; }
}
export type FAQ = { question: string; answer: string };
const defaultFAQs: FAQ[] = [
  { question: "Can I buy if I live outside Nigeria?", answer: "Yes. We can arrange a video walkthrough, share available documentation, and keep you in touch with our local team over WhatsApp or a call. We encourage buyers to get independent legal advice before completing a purchase." },
  { question: "Can I visit before I decide?", answer: "Of course. We are happy to arrange a guided inspection so you can see the location and ask questions on site." },
  { question: "What documents will I receive?", answer: "Documents vary by property. Each listing describes its title type, and our team will explain the relevant documents before you make a decision." }
];
export async function getFAQs(): Promise<FAQ[]> {
  if (!sanity) return defaultFAQs;
  try { const rows=await sanity.fetch<FAQ[]>(`*[_type == "faq"] | order(order asc) {question,answer}`, {}, { next: { revalidate: 60, tags: ["faqs"] } }); return rows.length?rows:defaultFAQs; }
  catch (error) { console.error("Sanity FAQs could not be loaded", error); return defaultFAQs; }
}
export type JournalPost = { title: string; slug: string; excerpt: string; image: string; publishedAt?: string; body: Array<Record<string, unknown>> };
export async function getPosts(): Promise<JournalPost[]> {
  if (!sanity) return [];
  try { const posts=await sanity.fetch<JournalPost[]>(`*[_type == "post" && defined(slug.current)] | order(publishedAt desc) {title, "slug": slug.current, excerpt, "image": coverImage.asset->url, publishedAt, body}`, {}, { next: { revalidate: 60, tags: ["journal"] } }); return posts.map(post=>({...post,image:optimizedImage(post.image,1200)||""})); }
  catch (error) { console.error("Sanity posts could not be loaded", error); return []; }
}
export async function getPost(slug: string): Promise<JournalPost | null> {
  if (!sanity) return null;
  try { const post=await sanity.fetch<JournalPost | null>(`*[_type == "post" && slug.current == $slug][0] {title, "slug": slug.current, excerpt, "image": coverImage.asset->url, publishedAt, body}`, { slug }, { next: { revalidate: 60, tags: ["journal"] } }); return post?{...post,image:optimizedImage(post.image,1600)||""}:null; }
  catch (error) { console.error("Sanity post could not be loaded", error); return null; }
}
export type GalleryPhoto = { title: string; caption?: string; image?: string; date?: string };
export async function getGallery(): Promise<GalleryPhoto[]> {
  if (!sanity) return [];
  try { return await sanity.fetch<GalleryPhoto[]>(`*[_type == "galleryItem"] | order(date desc) {title,caption,date,"image":image.asset->url}`, {}, { next: { revalidate: 60, tags: ["gallery"] } }); }
  catch (error) { console.error("Sanity gallery could not be loaded", error); return []; }
}
export async function getProperties(): Promise<Property[]> {
  if (!sanity) return demoProperties;
  try {
    const rows = await sanity.fetch<SanityListing[]>(`*[_type == "listing" && defined(slug.current)] | order(_createdAt desc) {title, slug, estate, district, address, price, previousPrice, size, propertyType, titleType, status, featured, description, "imageUrl": images[0].asset->url, "imageUrls": images[].asset->url, amenities, paymentPlan, seoTitle, seoDescription}`, {}, { next: { revalidate: 60, tags: ["properties"] } });
    return rows.map(row => ({ slug: row.slug?.current || "", title: row.title, estate: row.estate, district: row.district, address: row.address, price: row.price, previousPrice: row.previousPrice, size: row.size, propertyType: row.propertyType, titleType: row.titleType || "Title details to be confirmed", status: (row.status === "few" || row.status === "sold" ? row.status : "available") as Property["status"], featured: Boolean(row.featured), description: row.description || "", image: optimizedImage(row.imageUrl,1600) || demoProperties[0].image, images: (row.imageUrls || []).map(url=>optimizedImage(url,1400)||url), amenities: row.amenities || [], paymentPlan: row.paymentPlan || "Contact Dejohomes for current payment options.", seoTitle: row.seoTitle, seoDescription: row.seoDescription }));
  } catch (error) { console.error("Sanity listings could not be loaded", error); return demoProperties; }
}
