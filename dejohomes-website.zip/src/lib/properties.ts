export type Property = {
  slug: string; title: string; estate: string; district: string; address?: string; price: number; previousPrice?: number; size: number;
  propertyType?: string; titleType: string; status: "available" | "few" | "sold"; featured: boolean; description: string;
  image: string; images?: string[]; amenities: string[]; paymentPlan: string; seoTitle?: string; seoDescription?: string;
  imagePlaceholder?: boolean;
};

// Property details and prices below are transcribed from the Dejohomes flyers supplied for this prototype.
// Supplied renders are matched to the estate and square-metre size identified in each filename.
const vista200Image = "/properties/vista-grand-court-200sqm.jpg";
const vista300Image = "/properties/vista-grand-court-300sqm.jpg";
const vista450Image = "/properties/vista-grand-court-450sqm.jpg";
const peninsula150Image = "/properties/dejo-peninsula-150sqm.jpg";
const peninsula250Image = "/properties/dejo-peninsula-250sqm.jpg";
const peninsula350Image = "/properties/dejo-peninsula-350sqm.jpg";
const downtown250Image = "/properties/downtown-golf-resort-250sqm.png";
const downtown350Image = "/properties/downtown-golf-resort-350sqm.png";
const downtown450Image = "/properties/downtown-golf-resort-450sqm.png";
const downtown550Image = "/properties/downtown-golf-resort-550sqm.png";
const pendingTitle = "Title details to be confirmed";
const pendingPlan = "Contact Dejohomes for current payment options.";

export const properties: Property[] = [
  { slug: "vista-grand-court-200sqm", title: "200 sqm - 4 Bedroom Terrace Duplex", estate: "Vista Grand Court", district: "Asokoro II", address: "Asokoro II, FCT-Abuja", price: 9000000, previousPrice: 10500000, size: 200, propertyType: "4 Bedroom Terrace Duplex", titleType: pendingTitle, status: "available", featured: true, description: "Vista Grand Court, Asokoro II, FCT-Abuja. 200 sqm, 4 Bedroom Terrace Duplex. Flyer price: ₦9,000,000 (was ₦10,500,000; 15% off).", image: vista200Image, amenities: [], paymentPlan: pendingPlan },
  { slug: "vista-grand-court-300sqm", title: "300 sqm - 4 Bedroom Semi Detached with BQ", estate: "Vista Grand Court", district: "Asokoro II", address: "Asokoro II, FCT-Abuja", price: 13500000, previousPrice: 16000000, size: 300, propertyType: "4 Bedroom Semi Detached with BQ", titleType: pendingTitle, status: "available", featured: false, description: "Vista Grand Court, Asokoro II, FCT-Abuja. 300 sqm, 4 Bedroom Semi Detached with BQ. Flyer price: ₦13,500,000 (was ₦16,000,000).", image: vista300Image, amenities: [], paymentPlan: pendingPlan },
  { slug: "vista-grand-court-450sqm", title: "450 sqm - 5 Bedroom Fully Detached Duplex with BQ", estate: "Vista Grand Court", district: "Asokoro II", address: "Asokoro II, FCT-Abuja", price: 20000000, previousPrice: 22000000, size: 450, propertyType: "5 Bedroom Fully Detached Duplex with BQ", titleType: pendingTitle, status: "available", featured: false, description: "Vista Grand Court, Asokoro II, FCT-Abuja. 450 sqm, 5 Bedroom Fully Detached Duplex with BQ. Flyer price: ₦20,000,000 (was ₦22,000,000; flyer states 15% off).", image: vista450Image, amenities: [], paymentPlan: pendingPlan },

  { slug: "dejo-peninsula-150sqm", title: "150 sqm - 3 Bedroom Terrace Duplex", estate: "The Dejo Peninsula", district: "Kitti-Kabusa", address: "Kitti-Kabusa, FCT Abuja", price: 5850000, size: 150, propertyType: "3 Bedroom Terrace Duplex", titleType: pendingTitle, status: "available", featured: true, description: "The Dejo Peninsula, Kitti-Kabusa, FCT Abuja. 150 sqm, 3 Bedroom Terrace Duplex. Flyer price: ₦5,850,000.", image: peninsula150Image, amenities: [], paymentPlan: pendingPlan },
  { slug: "dejo-peninsula-250sqm", title: "250 sqm - 4 Bedroom Semi Detached Duplex", estate: "The Dejo Peninsula", district: "Kitti-Kabusa", address: "Kitti-Kabusa, FCT Abuja", price: 9750000, size: 250, propertyType: "4 Bedroom Semi Detached Duplex", titleType: pendingTitle, status: "available", featured: false, description: "The Dejo Peninsula, Kitti-Kabusa, FCT Abuja. 250 sqm, 4 Bedroom Semi Detached Duplex. Flyer price: ₦9,750,000.", image: peninsula250Image, amenities: [], paymentPlan: pendingPlan },
  { slug: "dejo-peninsula-350sqm", title: "350 sqm - 4 Bedroom Fully Detached Duplex", estate: "The Dejo Peninsula", district: "Kitti-Kabusa", address: "Kitti-Kabusa, FCT Abuja", price: 13650000, size: 350, propertyType: "4 Bedroom Fully Detached Duplex", titleType: pendingTitle, status: "available", featured: false, description: "The Dejo Peninsula, Kitti-Kabusa, FCT Abuja. 350 sqm, 4 Bedroom Fully Detached Duplex. Flyer price: ₦13,650,000.", image: peninsula350Image, amenities: [], paymentPlan: pendingPlan },

  { slug: "downtown-golf-resort-250sqm", title: "250 sqm - 2 Bedroom Semi-Detached Bungalow", estate: "Downtown Golf Resort", district: "Kuje", address: "After Handmaid Girls Secondary School, Kuje, Abuja FCT", price: 2700000, previousPrice: 3200000, size: 250, propertyType: "2 Bedroom Semi-Detached Bungalow", titleType: pendingTitle, status: "sold", featured: true, description: "Downtown Golf Resort, after Handmaid Girls Secondary School, Kuje, Abuja FCT. 250 sqm, 2 Bedroom Semi-Detached Bungalow. Flyer price: ₦2,700,000 (was ₦3,200,000).", image: downtown250Image, amenities: [], paymentPlan: pendingPlan },
  { slug: "downtown-golf-resort-350sqm", title: "350 sqm - 3 Bedroom Bungalow", estate: "Downtown Golf Resort", district: "Kuje", address: "After Handmaid Girls Secondary School, Kuje, Abuja FCT", price: 3500000, previousPrice: 4000000, size: 350, propertyType: "3 Bedroom Bungalow", titleType: pendingTitle, status: "available", featured: false, description: "Downtown Golf Resort, after Handmaid Girls Secondary School, Kuje, Abuja FCT. 350 sqm, 3 Bedroom Bungalow. Flyer price: ₦3,500,000 (was ₦4,000,000).", image: downtown350Image, amenities: [], paymentPlan: pendingPlan },
  { slug: "downtown-golf-resort-450sqm", title: "450 sqm - 4 Bedroom Bungalow with BQ", estate: "Downtown Golf Resort", district: "Kuje", address: "After Handmaid Girls Secondary School, Kuje, Abuja FCT", price: 4500000, previousPrice: 5000000, size: 450, propertyType: "4 Bedroom Bungalow with BQ", titleType: pendingTitle, status: "available", featured: false, description: "Downtown Golf Resort, after Handmaid Girls Secondary School, Kuje, Abuja FCT. 450 sqm, 4 Bedroom Bungalow with BQ. Flyer price: ₦4,500,000 (was ₦5,000,000).", image: downtown450Image, amenities: [], paymentPlan: pendingPlan },
  { slug: "downtown-golf-resort-550sqm", title: "550 sqm - 5 Bedroom Penthouse", estate: "Downtown Golf Resort", district: "Kuje", address: "After Handmaid Girls Secondary School, Kuje, Abuja FCT", price: 5500000, previousPrice: 6000000, size: 550, propertyType: "5 Bedroom Penthouse", titleType: pendingTitle, status: "available", featured: false, description: "Downtown Golf Resort, after Handmaid Girls Secondary School, Kuje, Abuja FCT. 550 sqm, 5 Bedroom Penthouse. Flyer price: ₦5,500,000 (was ₦6,000,000).", image: downtown550Image, amenities: [], paymentPlan: pendingPlan }
];

export const naira = (amount: number) => `₦${new Intl.NumberFormat("en-NG").format(amount)}`;
